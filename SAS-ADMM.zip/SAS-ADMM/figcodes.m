
 %% 
 

 
   h = figure;

 semilogy(Nit_cpu,  max(Averg_Obj_val1,Averg_Equ_err1), 'r-*',...
          Nit_cpu,  max(Averg_Obj_val2,Averg_Equ_err2), 'b-.>');
 xlabel('CPU time');ylabel('Opt\_err'); 
 legend('AS-ADMM','SAS-ADMM')